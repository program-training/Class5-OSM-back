interface Product {
  productId: number;
  name: string;
  description: string;
  price: number;
  quantity: number;
}
export default Product;
