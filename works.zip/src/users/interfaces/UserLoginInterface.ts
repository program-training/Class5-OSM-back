interface UserLoginInterface {
  email: string;
  password: string;
}

export default UserLoginInterface;
