// commonjsHelper.js
module.exports = __dirname;
