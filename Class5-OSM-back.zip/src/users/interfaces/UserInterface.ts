interface UserInterface {
  _id?: string;
  email: string;
  password: string;
  isadmin: boolean;
}

export default UserInterface;
